#include "router.h"
#include <stdio.h>
#include <stdlib.h>

static void free_result(RouteResult* result) {
    free(result->topk_indices);
    free(result->topk_scores);
    free(result->expert_load);
}

int main(void) {
    int num_tokens = 0;
    int num_experts = 0;
    int top_k = 0;

    if (scanf("%d %d %d", &num_tokens, &num_experts, &top_k) != 3) {
        return 1;
    }

    if (num_tokens <= 0 || num_experts <= 0 || top_k <= 0 || top_k > num_experts) {
        return 1;
    }

    int* scores = (int*)malloc((size_t)num_tokens * (size_t)num_experts * sizeof(int));
    if (scores == NULL) {
        return 1;
    }

    for (int i = 0; i < num_tokens; ++i) {
        for (int j = 0; j < num_experts; ++j) {
            if (scanf("%d", &scores[i * num_experts + j]) != 1) {
                free(scores);
                return 1;
            }
        }
    }

    RouteResult result;
    result.topk_indices = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    result.topk_scores = (int*)malloc((size_t)num_tokens * (size_t)top_k * sizeof(int));
    result.expert_load = (int*)malloc((size_t)num_experts * sizeof(int));

    if (result.topk_indices == NULL || result.topk_scores == NULL || result.expert_load == NULL) {
        free(scores);
        free_result(&result);
        return 1;
    }

    Router* router = router_create(num_experts, top_k);
    if (router == NULL) {
        free(scores);
        free_result(&result);
        return 1;
    }

    router_route(router, scores, num_tokens, &result);

    for (int i = 0; i < num_tokens; ++i) {
        printf("token %d:", i);
        for (int r = 0; r < top_k; ++r) {
            int idx = i * top_k + r;
            printf(" %d(%d)", result.topk_indices[idx], result.topk_scores[idx]);
        }
        printf("\n");
    }

    printf("load:");
    for (int j = 0; j < num_experts; ++j) {
        printf(" %d", result.expert_load[j]);
    }
    printf("\n");

    router_destroy(router);
    free(scores);
    free_result(&result);
    return 0;
}
