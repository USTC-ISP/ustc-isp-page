#ifndef ROUTER_H
#define ROUTER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int expert_id;
    int score;
} ExpertScore;

typedef struct {
    int num_experts;
    int top_k;
} Router;

typedef struct {
    int* topk_indices;
    int* topk_scores;
    int* expert_load;
} RouteResult;

Router* router_create(int num_experts, int top_k);
void router_route(Router* router, const int* scores, int num_tokens, RouteResult* out);
void router_destroy(Router* router);

#endif
